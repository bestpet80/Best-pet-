Best Pet - ওয়েবসাইট / Website
==============================

কীভাবে চালাবেন:
1. ZIP ফাইলটি Extract করুন।
2. index.html ফাইলটি ডাবল ক্লিক করে ব্রাউজারে খুলুন (ইন্টারনেট লাগবে, ফন্টের জন্য)।

অনলাইনে প্রকাশ করতে:
- পুরো best-pet-website ফোল্ডারটি Netlify, Vercel বা GitHub Pages-এ আপলোড করুন, অথবা আপনার হোস্টিংয়ের public_html ফোল্ডারে দিন।

ছবি বদলাতে:
- images ফোল্ডারে একই নামে নতুন ছবি দিন (যেমন royal-canin.webp)।
- ব্র্যান্ড, বিভাগ, সার্ভিস, ফোন, ইমেইল ও ঠিকানা index.html ফাইলের নিচের দিকে <script> অংশের শুরুতে (BRANDS, CATS, SERVICES, PHONE, EMAIL) আছে।

How to run: extract the ZIP and open index.html in a browser (internet needed for fonts).
To publish: upload the whole folder to Netlify, Vercel, GitHub Pages or your hosting's public_html.
